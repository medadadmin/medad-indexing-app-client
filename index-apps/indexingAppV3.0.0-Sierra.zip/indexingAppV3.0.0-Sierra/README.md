# Client-Indexer Application

Client-Indexer Application is an indexing application built with JAVA-Maven that read data from different sources (
Database, Files, URLs, etc...) and push them through an API into SOLR.

## Requirement

JRE 1.8

## How it works

To run the application you first have to fill the variables found in ***.env*** file then run the ***jar*** file with
the command:

```shell
java -jar build.jar 
```

#

### Environments Variables

```dotenv
# recommended environment variables for all systems
TYPE=marc
API_HOST=http://portal-dev.medad.com:9090
API_KEY=OGJkYWQ0YmMtNGQ1OC00YTI1LThhZTMtMzUxY2VjZjQwZTQz
API_TENANT=folio-docs
API_KEY_BROWSE=OGJkYWQ0YmMtNGQ1OC00YTI1LThhZTMtMzUxY2VjZjQwZTQz
API_TENANT_BROWSE=folio-browse
USE_UPDATE_DATE=true
SYNC_MODE=all
IS_DEBUG=false

# index type can be solr, so indexing app will call solr apis directly
INDEX_TYPE=solr
SOLR_URL=http://localhost:8983/solr/
SOLR_CORE=docs
SOLR_CORE_BROWSE=browse-docs


DB_HOST=jdbc:postgresql://192.168.1.1:5432/dbname
DB_USERNAME=username
DB_PASSWORD=pass
DB_NAME=dbname
DB_DRIVER=org.postgresql.Driver

#index rule type can either be sync or file, sync means to get index rules from server
INDEX_RULES_TYPE=sync
INDEX_RULE_MARC=IndexRules
INDEX_RULE_FOLIO=folioIndexRules

# folio environment variables
FOLIO_DB=okapi_modules
FOLIO_TENANT=medad

# configuration path
CONFIG_PATH=
TRANSLATIONS_PATH=

# use dynamic shcema
DYNAMIC_SCHEMA=true
# subfield delimiter 
SUBFIELD_DELIMITER=|
```



### `SYNC_MODE:`

1. **all** index + update + delete (track new records + update indexed records + delete deleted records)
2. **update** index + update (track new records + update indexed records )
3. **delete** delete (delete deleted records)
4. **bulk** index all data using bulk queries

## Configuration Files

### config.ini

The application read basic configuration from the file ``config.ini``
This file contains set of configurations that can be changed from one system to another. For example:

```editorconfig
[System]
index_from = System
batch_size = 200
number_of_threads = 1
update_date_field = updatedDate
id_field =

[FileFactory]
last_line = 1443272

[Sierra]
fixed_fields = SELECT * FROM table ;
tags = SELECT * FROM table2 ;
tags_bulk = SELECT * FROM table2 ;
items = SELECT * FROM table2 ;
suppress_query = SELECT * FROM table2 ;

[Folio]
instance_query = SELECT * FROM table ;
marc_query = SELECT * FROM table ;
types_query = SELECT * FROM table ;
items_query = SELECT * FROM table ;
suppress_query = SELECT * FROM table ;

```

here we can change ``index_from`` to set the desired system, then we can add the system for example ``[Sierra]`` and add
our custom queries ``fixed_fields`` & ``marc_tags``, also we can change ``batch_size`` and other fields found in this
file.

#

### indexRules

Index rules file is configuration file responsible for the fields mapping of Marc records. You can find a sample index
rules in **sample-configs** folder and here's how it works:

```
 i|245|||title_se|a,b| |1|display|false
```

- Each line of this file represent a Marc tag.
- Each line is divided into 10 parts separated by **|**.
- First part can be either `i` or `e`, `i` means **include** the set of Marc tags and `e` means **exclude**.
- Second part `1**` is the Marc tag, it can be either full number for example `200` or with `2**` to include all tags
  starting with `2`.
- Third and Fourth parts are for the indicators (1&2).
- Then `field_name` we want in our schema, for the dynamic creation of the fields, you can use the name suffix ("_se","_
  fa","_srt","_str").
- Then **subfields** where it can be `all` (to include all subfields), or it can be set of subfields for
  example `a:b:z` (to include this set of subfields)
- Then the **character** we want to replace the subfield with.
- Then a **flag** whether to replace special characters or not.
- Then the **function** we need to use to get the value. NB: all functions should be implemented
  in `utils/UtilsFunctions.java`.
- Then a **boolean** that indicates if the field is multi-value or not.

#

### folioIndexRules

Folio index rules are the rules set to index instances from folio databases and here how it works:

```
 solrField|jsobKey|elementKey:elementKey|type|typeId|condition
```

- Each line represent Solr field
- Each line is divided into six parts separated by `|`
- `solrField` is the field set in Solr schema
- `jsobKey` is the key of the instance to be selected
- `elementKey` is the key of the elements inside the object key (elements key can have multi values separated by `:` )
- `type` is the type to be selected from the types query for the selected field
- `typeId` is the key-name of the type ID
- `condition` condition (key name) to select the value of the selected field




 